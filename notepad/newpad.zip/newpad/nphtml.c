/*
 * HTML support functions
 *  Copyright (C) 2000 Microsoft Corporation
 */

#include "precomp.h"


BOOL FDetectHtmlEncodingA(LPCSTR rgch, UINT cch, UINT* pcp)
{
    return(FALSE);
    UNREFERENCED_PARAMETER( rgch );
    UNREFERENCED_PARAMETER( cch );
    UNREFERENCED_PARAMETER( pcp );
}


BOOL FDetectHtmlEncodingW(LPCWSTR rgch, UINT cch, UINT* pcp)
{
    return(FALSE);
    UNREFERENCED_PARAMETER( rgch );
    UNREFERENCED_PARAMETER( cch );
    UNREFERENCED_PARAMETER( pcp );
}
